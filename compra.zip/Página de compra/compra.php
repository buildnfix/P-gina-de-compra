<!DOCTYPE html>
<html>
<head>
	<title>Build N' Fix</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>

<!--- começo do código da nav---->
	<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #FFCA28">
		<a class="navbar-brand h2 ml-4" href="index.html">Build N' Fix</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#NavbarSite">
				<span class="navbar-toggler-icon"></span>
		 	</button>

<!---- #navbarsite é o link para o menu responsivo que aparece quando a vizualização é em tamanho tablet/celular --->
	<div class="collapse navbar-collapse" id="NavbarSite">
	  	<div class="container">
	  		<ul class="navbar-nav">
	  			<li class="nav-item">							
	  				<a class="nav-link" href="#"> Home </a>
	  		 	</li>

	  			<li class="nav-item">
	  				<a class="nav-link" href="#"> Profissionais </a>
	  		 	</li>

	  		 	<li class="nav-item">
	  				<a class="nav-link" href="#"> Contratar </a>
	  		 	</li>

	  		 	<li class="nav-item">
	  				<a class="nav-link" href="#"> Termos </a>
			   </li>

			   <li class="nav-item">
				<a href="" class="btn btn-dark" data-toggle="modal" data-target="#modalLoginForm" style="margin-left: 690px;">Login</a>
			   </li>
				
	  		</ul>
	  	</div>
	  	  </div>
	</nav>
<!------ fim da nav--->	

<!----formulario modal de cadastro-->
<form name="login" action="#" method="POST"
<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
		<h4 class="modal-title w-100 font-weight-bold">Entrar no Build N' Fix</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body mx-3">
        <div class="md-form mb-5">
          <i class="fa fa-camera-retro"></i>
          <input type="email" id="defaultForm-email" class="form-control validate">
          <label data-error="wrong" data-success="right" for="defaultForm-email">Email</label>
        </div>

        <div class="md-form mb-4">
          <i class="fas fa-lock prefix grey-text"></i>
          <input type="password" id="defaultForm-pass" class="form-control validate">
          <label data-error="wrong" data-success="right" for="defaultForm-pass">Senha</label>
        </div>

      </div>
      <div class="modal-footer">
		<div class="options text-center text-md-right mt-1">
		  <p>Esqueceu a senha?<a href="#" class="text-warning"> Clique aqui.</a></p>
		</div>
		<button type="button" class="btn btn-outline-warning mr-3 waves-effect ml-auto" href="#">Entrar</button>
	  </div>

	</div>
  </div>
</div>
</form>

<!----fim do formulario--> 
<center>
  <h1 class="display-4 mt-5">Nossos planos</h1>
  <h6 class="lead text-muted"> Para todas as necessidades, para todos os profissionais. </h6>

<!----início dos cards de planos-------------------------------------------------------------->

<div class="row" style="margin-bottom: 130px;">
  <div class="col-sm-3 mt-5" style="margin-left:25%;">  
    <div class="card" style="width: 18rem;">
       <img class="card-img-top" src="img\loft.jpg" alt="Plano Loft">
       <div class="card-body">
          <h5 class="card-title">Plano Loft</h5>
         <p class="card-text lead">Um plano simples, um grande passo.</p>
         </div>
       <ul class="list-group list-group-flush">
          <li class="list-group-item">Básico e dinâmico.</li>
          <li class="list-group-item text-warning">R$20/mês </li>
          <li class="list-group-item">Upload de até 10 fotos no portfólio.</li>
          <li class="list-group-item">Sem destaque no feed principal.</li>
      
      </ul>
        <div class="card-body">
          <button type="button" class="btn btn-warning"> Adquirir </button>
        </div>
    </div>
  </div>

   <div class="col-sm-3 mt-5">  
    <div class="card" style="width: 18rem;">
       <img class="card-img-top" src="img\master.jpg" alt="Card image cap">
       <div class="card-body">
          <h5 class="card-title">Plano Master</h5>
         <p class="card-text lead">A experiência completa e sua praticidade garantida.</p>
         </div>
       <ul class="list-group list-group-flush">
          <li class="list-group-item">Completo e inovador.</li>
          <li class="list-group-item text-warning">R$30/mês</li>
          <li class="list-group-item">Upload de até 50 fotos no portfólio.</li>
           <li class="list-group-item">Destaque no feed principal.</li>


      </ul>
        <div class="card-body">
          <button type="button" class="btn btn-warning"> Adquirir </button>
        </div>
    </div>
  </div>

</div>
</div>
</center>
<!-----------------fooooooooooooooooooooooooooooooooter------>

	<center>
    <div id="footer">
      <hr color="#c2c2c2">
      	<h1 class="lead text-white"> <font size="6"> Build N' Fix </font></h1>
      	<h6 class="lead text-muted">Construir nunca foi tão fácil.</h6>

      	<ul class="site-links list-inline">
      		<li class="list-inline-item">
      			<a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Quem somos </a>
      		</li>

      		<li class="list-inline-item">
      			<a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Contato </a>
      		</li>

      		<li class="list-inline-item">
      			<a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Suporte </a>
      		</li>

      	</ul>

      		<form id="formularionews" action=#>

      			<div class="form-group"> 
      				<input type="text" name="contato" id="contato" placeholder="Assine nossa Newsletter">
      				<button type="button" class="btn btn-outline-light" id="btnews">Inscrever</button>
      			</div>
      		</form> <br>

      	<h5 class="lead text-white-50"> Etec de Santa Isabel, Santa Isabel-SP</h4> <br>
      	<h5 class="lead text-white">buildnfix@email.com</h4> <br>
      		<div id="copyright">
      			<p class="lead text-muted"> <br> @2019 Build 'N Fix. Todos os direitos reservados. </p>

      		</div>

    </div>

  </center>

<!-------------------------------------------------------------------------------------------------------------------------->
    </body>
</html>